<?php
include("header.php");
?>
<div id="templatemo_main"><span class="main_top"></span>
  <div id="templatemo_content">
    <table width="386" border="1">
      <tr>
        <th colspan="2" scope="col">TRANSACTION DETAILS</th>
        </tr>
      <tr>
        <td>ACCOUNT NUMBER</td>
        <td>1545858</td>
      </tr>
      <tr>
        <td>TRANSACTION NO</td>
        <td>4844</td>
      </tr>
      <tr>
        <td>TRANSACTION DATE</td>
        <td>12-02-2012</td>
      </tr>
      <tr>
        <td>TRANSACTION AMOUNT</td>
        <td>10000</td>
      </tr>
      <tr>
        <td>TRANSACTION TYPE</td>
        <td>CHECK</td>
      </tr>
      <tr>
        <td>TRANSACTION DESCRIPTION </td>
        <td>PAID BILL</td>
      </tr>
    </table>
</div><!-- end of content -->
            
            <div id="templatemo_sidebar">
            
       <?php
	   include("myaccountssidebar.php");
	   ?>
                

                
                <div class="cleaner_h40"></div>
                
                <h2>Testimonial</h2>
                <blockquote>
                <p>In ac libero urna. Suspendisse sed odio ut mi auctor blandit. Duis luctus nulla metus. Validate <a href="http://validator.w3.org/check?uri=referer" rel="nofollow"><strong>XHTML</strong></a> &amp; <a href="http://jigsaw.w3.org/css-validator/check/referer" rel="nofollow"><strong>CSS</strong></a>.</p>
                
                <cite>David - <span>Web Specialist</span></cite>
                </blockquote>
            
            </div>
                
		<div class="cleaner"></div>
     </div>     <!-- end of main -->
    <div id="templatemo_main_bottom"></div><!-- end of main -->
    
    <?php
	include("footer.php");
	?>