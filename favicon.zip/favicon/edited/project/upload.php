<!DOCTYPE html>
<html lang="en">
<body>
 <form action="upload.php" method="post" enctype="multipart/form-data">
select image to upload;
<input type="file" name="image"/>
<input type ="submit" name="submit" value="UPLOAD" />
</form>


<?php
if(isset($_POST["submit"])){
 $check = getimagesize($_FILES["image"]["tmp_name"]);
if($check !==FALSE){
$image = $_FILES['image'] ['tmp_name'];
$name = $_FILES['image']['name'];
$move="images/".$name;
$x = move_uploaded_file($_FILES['image']['tmp_name'], $move);
if($x)
{
	echo "Good";
}

$db = new mysqli('localhost','root','','2bank');
if($db->connect_error){
die("connection failed" . $db->connect_error);}
$datatime = date("y-m-d H:i:s");
$insert= $db->query("INSERT into trial (id,image, created) VALUES ('','$name', '$datatime')");
if($insert){
echo "file uploaded succesfully.";}
else { echo "File upload failed ,please try again.";
}
}
else{
echo "Please select an image to upload";
}
}
?>
</body>
</html>