<?php
include("header.php");
?>
<div id="templatemo_main"><span class="main_top"></span>
  <div id="templatemo_content">
    <p align="center">TRANSACTION MADE</p>
    <table width="404" border="1">
      <tr>
        <th scope="col"><p>ACCOUNT NUMBER:185722</p>
          <p>FROM :02-05-2010  TO 26-09-2013</p>
          <p>TRANSACTION TYPE: CREADIT ONLY</p></th>
      </tr>
    </table>
    <table width="417" height="191" border="1">
      <tr>
        <th colspan="9" scope="col">TRANSACTION MADE</th>
        </tr>
      <tr>
        <td>SL NO</td>
        <td>DATE</td>
        <td>TRANSACTION NUMBER</td>
        <td>PARTICULARS</td>
        <td>DATE</td>
        <td>TRANS TYPE</td>
        <td>CHEQUE NO</td>
        <td>DEPOSITS</td>
        <td>BALANCE AMT</td>
      </tr>
      <tr>
        <td>&nbsp;</td>
        <td>&nbsp;</td>
        <td>&nbsp;</td>
        <td>&nbsp;</td>
        <td>&nbsp;</td>
        <td>&nbsp;</td>
        <td>&nbsp;</td>
        <td>&nbsp;</td>
        <td>&nbsp;</td>
      </tr>
      <tr>
        <td>&nbsp;</td>
        <td>&nbsp;</td>
        <td>&nbsp;</td>
        <td>&nbsp;</td>
        <td>&nbsp;</td>
        <td>&nbsp;</td>
        <td>&nbsp;</td>
        <td>&nbsp;</td>
        <td>&nbsp;</td>
      </tr>
      <tr>
        <td>&nbsp;</td>
        <td>&nbsp;</td>
        <td>&nbsp;</td>
        <td>&nbsp;</td>
        <td>&nbsp;</td>
        <td>&nbsp;</td>
        <td>&nbsp;</td>
        <td>&nbsp;</td>
        <td>&nbsp;</td>
      </tr>
    </table>
    <p>&nbsp;</p>
</div><!-- end of content -->
            
            <div id="templatemo_sidebar">
            
       <?php
	   include("myaccountssidebar.php");
	   ?>
                

                
                <div class="cleaner_h40"></div>
                
                <h2>Testimonial</h2>
                <blockquote>
                <p>In ac libero urna. Suspendisse sed odio ut mi auctor blandit. Duis luctus nulla metus. Validate <a href="http://validator.w3.org/check?uri=referer" rel="nofollow"><strong>XHTML</strong></a> &amp; <a href="http://jigsaw.w3.org/css-validator/check/referer" rel="nofollow"><strong>CSS</strong></a>.</p>
                
                <cite>David - <span>Web Specialist</span></cite>
                </blockquote>
            
            </div>
                
		<div class="cleaner"></div>
     </div>     <!-- end of main -->
    <div id="templatemo_main_bottom"></div><!-- end of main -->
    
    <?php
	include("footer.php");
	?>