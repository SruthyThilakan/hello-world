<?php
session_start();
include("header.php");
include("dbconnection.php");
$recres="";
if(isset($_SESSION["userid"]))
{
  $customer = $_SESSION["userid"];
}
else
{
  header("Location: mailcompose.php");
  session_destroy();
}
if(isset($_GET["mailid"]))
{
	mysqli_query($connection, "DELETE FROM mail where mailid='$_GET[mailid]'");
  $recres = "Mail deleted Successfully...";
  
}
 
$result = mysqli_query($connection, "SELECT * FROM mail where reciverid='$customer'");
?>
    
     <div id="templatemo_main">
  <div align="center"><span class="main_top"></span> 
    
  </div>
  <div align="center"></div>
  <div id="templatemo_content">
     		 <h2 align="center">INBOX</h2>
            <?php echo $recres; ?>
         <table width="600" border="1">
    
             
              <?php
		 echo " <tr>";
                echo " <th scope='col' width='45' >Delete</th>";
                echo " <th scope='col'>SENDER</th>";
                echo " <th scope='col'>SUBJECT</th>";
                echo " <th scope='col'>TIME</th>";
                echo " </tr>";
         		while($row = mysqli_fetch_array($result))
  				{
    			echo " <tr>";
                echo " <th scope='col'><a href='mailinbox.php?mailid=$row[mailid]'>Delete</a></th>";
                echo " <th scope='col'>$row[senderid]</th>";
                echo " <th scope='col'>$row[subject]</th>";
                echo " <th scope='col'>$row[mdatetime]</th>";
                echo " </tr>";
  				}
?>           
      </table>
       	  </form>
        <?php

?>
<div class="cleaner_h50"></div>
        </div><!-- end of content -->
            
            <div id="templatemo_sidebar">
            
              <?php
			include("custsidebar.php");
			mails();
                ?>
                
              <div class="cleaner_h40"></div>
                
                <h2>&nbsp;</h2>
</div>
                
		<div class="cleaner"></div>
     </div>     <!-- end of main -->
    <div id="templatemo_main_bottom"></div><!-- end of main -->
    
 
    
    <?php
	include("footer.php");
	?>




