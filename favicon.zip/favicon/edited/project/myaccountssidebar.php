

<html>

     <h1>My Accounts</h1><br/>

                <ul class="templatemo_list">
                <li><a href="accountsummary.php">Accounts summary</a></li>
                <li><a href="ministatements.php">Mini statement</a></li>
                <li><a href="accdetails.php">Account details</a></li>
                
                </ul>

</html>