<?php
 session_start();
 $_SESSION['message']='';
  
	$db= mysqli_connect("localhost","root","","2bank");

 if($_SERVER['REQUEST_METHOD']== 'POST'){
	 	 
	 	 
	 $user_name=$db->real_escape_string($_POST['userid']);
	 $first_name=$db->real_escape_string($_POST['firstname']);
	 $last_name=$db->real_escape_string($_POST['lastname']);
	 $city=$db->real_escape_string($_POST['city']);
	 $state=$db->real_escape_string($_POST['state']);
	 $country=$db->real_escape_string($_POST['country']);
	 $image_path=$db->real_escape_string('image/'.$_FILES['image']['name']);
	 $ifsccode=$db->real_escape_string($_POST['ifsccode']);
	 $bool=true;

	    $query=$db->query("SELECT * FROM customer");	
		while($row=mysqli_fetch_array($query))
		{
			$table_user=$row['userid'];
			if($user_name==$table_user)
			{
				$bool=false;
				Print '<script>alert("userid has already been taken!");</script>';
				Print '<script>window.location.assign("register.php");</script>';
			}
		}
		if($bool)
		{
				
	        if(preg_match("!image!",$_FILES['image']['type'])){
				
		        if(copy($_FILES['image']['tmp_name'],$image_path)){
					
			         $_SESSION['userid']=$user_name;
			         $_SESSION['firstname']=$first_name;
			         $_SESSION['lastname']=$last_name;
			         $_SESSION['city']=$city;
			         $_SESSION['state']=$state;
			         $_SESSION['country']=$country;
			         $_SESSION['image']=$image_path;
					 $_SESSION['ifsccode']=$ifsccode;
			 
					$datetime = date("y-m-d h:i:s");
			        $sql= $db->query("INSERT into customer(userid,firstname,lastname,city,state,country,image,lastlogin,ifsccode) 
					values('$user_name','$first_name','$last_name','$city','$state','$country','$image_path','$datetime','$ifsccode')");
			 
			         if($db->query($sql)===true){
				         $_SESSION['message']='Registration successful!'; 
			        }
			        else{
				         $_SESSION['message']='Registration Failed';
			        }
		        }
		       else{
			         $_SESSION['message']='file upload failed';
	            }
			}	
	       else{
		         $_SESSION['message']='please only upload jpg';
            }
	     
        }

 }
?>

<html>
<head>
    <title>Online Banking Registration</title>
</head>
<style>


*{  
  margin:0;
  padding:0;
}

h1 {
  font-size: 2em;
  font-family: "Core Sans N W01 35 Light";
  font-weight: normal;
  margin: .67em 0;
  display: block;
}


img {
    margin-bottom: 20px;
}

.image {
    margin: 10px 0 20px 0;
}

.module{
  position:relative;
  top:10%;    
  height:65%;
  width:450px;
  margin-left:auto;
  margin-right:auto;
}

body{
  color: #fff;
  background-color:#f0f0f0;
  font-family:helvetica;
  background:#0f2439 no-repeat center top;
}

.body-content{
  position:relative;
  top:20px;
  height:700px;
  width:800px;
  margin-left:auto;
  margin-right:auto; 
  background: transparent;
}

select,
textarea,
input[type="text"]
{
  height:30px;
  width:100%;;
  display: inline-block;
  vertical-align: middle;
  height: 34px;
  padding: 0 10px;
  margin-top: 3px;
  margin-bottom: 10px;
  font-size: 15px;
  line-height: 20px;
  border: 1px solid rgba(255, 255, 255, 0.3);
  background-color: rgba(0, 0, 0, 0.5);
  color: rgba(255, 255, 255, 0.7);
  -moz-box-sizing: border-box;
  box-sizing: border-box;
  border-radius: 2px;
}



.btn {
  text-overflow: ellipsis;
  white-space: nowrap;
  overflow: hidden;
  margin: 3px 0;
  padding: 6px 20px;
  font-size: 15px;
  line-height: 20px;
  height: 34px;
  background-color: rgba(0, 0, 0, 0.15);
  color: #00aeff;
  border: 1px solid rgba(255, 255, 255, 0.15);
  box-shadow: 0 0 rgba(0, 0, 0, 0);
  border-radius: 2px;
  -webkit-transition: background-color 0.2s, box-shadow 0.2s, background-color 0.2s, border-color 0.2s, color 0.2s;
  transition: background-color 0.2s, box-shadow 0.2s, background-color 0.2s, border-color 0.2s, color 0.2s;
}
.btn.active,
.btn:active {
  padding: 7px 19px 5px 21px;
}
.btn.disabled:active,
.btn[disabled]:active,
.btn.disabled.active,
.btn[disabled].active {
  padding: 6px 20px !important;
}
.btn:hover,
.btn:focus {
  background-color: rgba(0, 0, 0, 0.25);
  color: #ffffff;
  border-color: rgba(255, 255, 255, 0.3);
  box-shadow: 0 0 rgba(0, 0, 0, 0);
}
.btn:active,
.btn.active {
  background-color: rgba(0, 0, 0, 0.15);
  color: rgba(255, 255, 255, 0.8);
  border-color: rgba(255, 255, 255, 0.07);
  box-shadow: inset 1.5px 1.5px 3px rgba(0, 0, 0, 0.5);
}
.btn-primary {
  background-color: #098cc8;
  color: #ffffff;
  border: 1px solid transparent;
  box-shadow: 0 0 rgba(0, 0, 0, 0);
  border-radius: 2px;
  -webkit-transition: background-color 0.2s, box-shadow 0.2s, background-color 0.2s, border-color 0.2s, color 0.2s;
  transition: background-color 0.2s, box-shadow 0.2s, background-color 0.2s, border-color 0.2s, color 0.2s;
  background-image: -webkit-linear-gradient(top, #0f9ada, #0076ad);
  background-image: linear-gradient(to bottom, #0f9ada, #0076ad);
  border: 0;
  box-shadow: 0 1px 1px rgba(0, 0, 0, 0.3), 0 0 0 1px rgba(255, 255, 255, 0.15) inset;
}
.btn-primary:hover,
.btn-primary:focus {
  background-color: #21b0f1;
  color: #ffffff;
  border-color: transparent;
  box-shadow: 0 0 rgba(0, 0, 0, 0);
}
.btn-primary:active,
.btn-primary.active {
  background-color: #006899;
  color: rgba(255, 255, 255, 0.7);
  border-color: transparent;
  box-shadow: inset 1.5px 1.5px 3px rgba(0, 0, 0, 0.5);
}
.btn-primary:hover,
.btn-primary:focus {
  background-image: -webkit-linear-gradient(top, #37c0ff, #0097dd);
  background-image: linear-gradient(to bottom, #37c0ff, #0097dd);
}
.btn-primary:active,
.btn-primary.active {
  background-image: -webkit-linear-gradient(top, #006ea1, #00608d);
  background-image: linear-gradient(to bottom, #006ea1, #00608d);
  box-shadow: 1px 1px 2px rgba(0, 0, 0, 0.6) inset, 0 0 0 1px rgba(255, 255, 255, 0.07) inset;
}
.btn-block {
  display: block;
  width: 100%;
  padding-left: 0;
  padding-right: 0;
}

.alert {
  -moz-box-sizing: border-box;
  box-sizing: border-box;
  padding: 4px 20px 4px 20px;
  font-size: 13px;
  line-height: 20px;
  margin-bottom: 20px;
  text-shadow: none;
  position: relative;
  background-color: #272e3b;
  color: rgba(255, 255, 255, 0.7);
  border: 1px solid #000;
  box-shadow: 0 0 0 1px #363d49 inset, 0 5px 10px rgba(0, 0, 0, 0.75);
}
.alert-error {
  color: #f00;
  background-color: #360e10;
  box-shadow: 0 0 0 1px #551e21 inset, 0 5px 10px rgba(0, 0, 0, 0.75);
}
.alert:empty{
    display: none;
}
.alert-success {
  color: #21ec0c;
  background-color: #15360e;
  box-shadow: 0 0 0 1px #2a551e inset, 0 5px 10px rgba(0, 0, 0, 0.75);
}
</style>



<link rel="stylesheet" href="register.css" type="text/css">
<div class="body-content">
  <div class="module">
    <h1>Create an account</h1>
    <form class="form" action="register.php" method="post" enctype="multipart/form-data" autocomplete="off">
	<div class="alert alert-error"><?=$_SESSION['message'] ?></div>
	 <table cellpadding="20" cellspacing="20" style="text-align:left;margin-left:0em" >
      <div class="alert alert-error"></div>
	  <tr>
	       <td><label>User ID</label></td>
           <td><input type="text" placeholder="UserID" name="userid" required /></td>
      </tr>
	  <tr>
	       <td><label>IFSC Code</label></td>
           <td><input type="text" placeholder="IFSC Code" name="ifsccode" required /></td>
      </tr>
	  <tr>
	       <td><label>First Name</label></td>
           <td><input type="text" placeholder="First Name" name="firstname" required /></td>
      </tr>
	  <tr>
	       <td><label>Last Name</label></td>
	       <td><input type="text" placeholder="Last Name" name="lastname" required /></td> 
      </tr>
	  <tr>
	      <td><label>City</label></td>
          <td><input type="text" placeholder="City" name="city" required /></td>
	  </tr>
	  <tr>
	       <td><label>State</label>
	       <td><input type="text" placeholder="State" name="state" required /></td>
	  </tr>
	  <tr>
	       <td><label>Country</label</td>
	       <td><input type="text" placeholder="Country" name="country" required /></td>
	  </tr>
	  
      <tr>	  
      <td><div class="image"><label>Upload Image for setting Password</label></td>
	  <td><input type="file" name="image" accept="image/*" required /></div></td>
	  </tr>
	  <tr>
      <td><input type="submit" value="Register" name="register" class="btn btn-block btn-primary" /></td>
	  </tr>
	  <p><td>Already a member? <a href="login.php">Sign in</a></td></p>
	</table>
    </form>
  </div>
</div
</body>
</html>