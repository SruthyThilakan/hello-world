<html>
<head>
    <title>Online Banking Registration</title>
</head>
<body>
<link rel="stylesheet" href="style.css" type="text/css">
<div class="body-content">
  <div class="module">
  <h1>Your registration was successful!!</h1>
  <p><span class="heading">This is your image password!!</p>
  <p><span class="heading"> DON'T SHARE YOUR PASSWORD. KEEP IT SECRET</p>
  <p><span class="heading">Please right click on this image and save it as png file</p>
  
  <img src="image/share1.png" height="50%" width="50%"/>
  </div>
  </div>
  </body>