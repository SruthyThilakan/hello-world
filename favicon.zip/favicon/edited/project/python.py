from PIL import Image, ImageChops
import sys
import random

def random_pixel(n):
    a = random.random()
    if a<n:
       s= 255
    else:
       s= 0 
    return s              

def fgvss(imageName1, imageName2, outputfilename1, outputfilename2, outputfilename3):
    k=0.5
    colorImageName1 = Image.open(imageName1)
    covim = Image.open(imageName2)
    gray1 = colorImageName1.convert('L')
    secim = gray1.point(lambda x: 0 if x<128 else 255, '1')
    pixelMaps = secim.load()
    pixelMapc = covim.load()
    share1 = Image.new("1", (600,600), color=255)
    share2 = Image.new("1", (600,600), color=255)
    result = Image.new("1", (600,600), color=0)
    pixelMapshare1 = share1.load()
    pixelMapshare2 = share2.load()

    for i in range(0,600):
        for j in range(0,600):
            if(pixelMapc[i,j] == 0):
                pixelMapshare1[i,j] = random_pixel(k/2)
                if(pixelMaps[i,j] == 255):
                    if(pixelMapshare1[i,j] == 255):
                        pixelMapshare2[i,j] = 255
                    else:
                        pixelMapshare2[i,j] = random_pixel(1-(k/(2-k)))
                else:
                    pixelMapshare2[i,j] = not pixelMapshare1[i,j]
            else:
                pixelMapshare1[i,j] = random_pixel(1-(k/2))
                if(pixelMaps[i,j] == 255):
                    if(pixelMapshare1[i,j] == 255):
                        pixelMapshare2[i,j] = random_pixel(k/(2-k))
                    else:
                        pixelMapshare2[i,j] = 0
                else:
                    pixelMapshare2[i,j] = not pixelMapshare1[i,j]

    pixelMapshare1 = share1.load()
    pixelMapshare2 = share2.load()     
    result = ImageChops.logical_xor(share1,share2)
    result = ImageChops.invert(result)
    share1.save(outputfilename1)
    share2.save(outputfilename2)
    result.save(outputfilename3)

#Main Program

arg1 = str(sys.argv[1])
arg2 = str(sys.argv[2])
arg3 = str(sys.argv[3])
arg4 = str(sys.argv[4])
arg5 = str(sys.argv[5])
fgvss(arg1, arg2, arg3, arg4, arg5)