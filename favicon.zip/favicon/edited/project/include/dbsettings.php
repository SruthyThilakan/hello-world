
<?php

/*
***************************************************
***Examination Management System                ***
***---------------------------------------------***
*** Developer: Dejene Techane                   ***
*** Title: Database Settings                    ***
***************************************************
*/

//This is the name of your server where the MySQL database is running
$dbserver="localhost";

//username of the MySQL server
$dbusername="root";

//password

$dbpassword="1838/02";

//database name of the online Examination system
$dbname="ems";

?>
