<nav id="primary_nav_wrap">
<ul>
 
  <li><a href="#">Course</a>
    <ul>
      <li><a href="coursemng.php" alt="Manage Courses" title="This takes you to Course Management Section">Manage Courses</a></li>
       
          </li>
          
    </ul>
  </li>
  <li><a href="#">Student</a>
    <ul>
      <li><a href="usermng.php" alt="Manage Users" title="This takes you to User Management Section">Manage Students</a></li>
      
    </ul>
  </li>  
  <li><a href="#">Instructor</a>
    <ul>
      <li><a href="insmng.php" alt="Manage Instructors" title="This takes you to Instructor Management Section">Manage Instructors</a></li>
      
    </ul>
  </li>    
  <li><a href="#">Assessment</a>
    <ul>
      <li><a href="underconstruction.php">Aprove Assessment</a></li>
      
    </ul>
  </li>
  <li><a href="#">Grade</a>
    <ul>
      <li><a href="underconstruction.php">Aprove Grade</a></li>
      
    </ul> 
     <li><a href="#">Account</a>
    <ul>
      <li><a href="changepass.php?edit=edit" alt="Edit Your Password" title="This takes you to Edit Password Section">Change Password</a></li>
      
    </ul> 
  </li>
</nav>