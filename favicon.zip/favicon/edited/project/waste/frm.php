<?php
 session_start();
 include "header.php";
 $_SESSION['message']='';
  
	$db= mysqli_connect("localhost","root","","3bank");

 if($_SERVER['REQUEST_METHOD']== 'POST'){
	 	 
	 	 
	 $userid=$db->real_escape_string($_POST['userid']);
	 $first_name=$db->real_escape_string($_POST['firstname']);
	 $last_name=$db->real_escape_string($_POST['lastname']);
	 $city=$db->real_escape_string($_POST['city']);
	 $state=$db->real_escape_string($_POST['state']);
	 $country=$db->real_escape_string($_POST['country']);
	 $image_path=$db->real_escape_string('image/'.$_FILES['image']['name']);
	 $ifsccode=$db->real_escape_string($_POST['ifsccode']);
	 $email=$_POST['email'];
	 $mobile=$_POST['mobile'];
	 $bool=true;
	 

	    $query=$db->query("SELECT * FROM customer");	
		while($row=mysqli_fetch_array($query))
		{
			$table_user=$row['userid'];
			if($userid==$table_user)
			{
				$bool=false;
				Print '<script>alert("userid has already been taken!");</script>';
				Print '<script>window.location.assign("frm.php");</script>';
			}
		}
		if($bool)
		{
				
	        if(preg_match("!image!",$_FILES['image']['type'])){
				
		        if(copy($_FILES['image']['tmp_name'],$image_path)){
					
			       
			         $_SESSION['firstname']=$first_name;
			         $_SESSION['lastname']=$last_name;
			         $_SESSION['city']=$city;
			         $_SESSION['state']=$state;
			         $_SESSION['country']=$country;
			         $_SESSION['image']=$image_path;
					 $_SESSION['ifsccode']=$ifsccode;
					 $_SESSION['email']=$email;
					 $_SESSION['mobile']=$mobile;
			 
					$datetime = date("y-m-d H:i:s");
			         $sql= $db->query("INSERT into customer(userid,firstname,lastname,city,state,country,image,lastlogin,ifsccode,email,mobile)
					 values('$userid','$first_name','$last_name','$city','$state','$country','$image_path','$datetime','$ifsccode','$email','$mobile')");
			 
			         if($db->query($sql)===true){
				         $_SESSION['message']='Registration successful!'; 
			        }
			        else{
				         $_SESSION['message']='Registration failed';
			        }
		        }
		       else{
			         $_SESSION['message']='file upload failed';
	            }
			}	
	       else{
		         $_SESSION['message']='please only upload jpg/jpeg/png';
            }
	        //Print '<script>window.location.assign("123.php");</script>';		
        }

 }
?>

<html>
<head>
    <title>Online Banking Registration</title>
</head>
<link rel="stylesheet" href="style.css" type="text/css">
<div class="body-content">
  <div class="module">
    <h1>Create an account</h1>
    <form class="form" action="frm.php" method="post" enctype="multipart/form-data" autocomplete="off">
	<div class="alert alert-error"><?=$_SESSION['message'] ?></div>
	 <table cellpadding="20" cellspacing="20" style="text-align:left;margin-left:0em" >
      <div class="alert alert-error"></div>
	  <tr>
	       <td><label>User ID</label></td>
           <td><input type="text" placeholder="Usern ID" name="userid" required /></td>
      </tr>
	  <tr>
	       <td><label>IFSC Code</label></td>
           <td><input type="text" placeholder="IFSC Code" name="ifsccode" required /></td>
      </tr>
	  <tr>
	       <td><label>First Name</label></td>
           <td><input type="text" placeholder="First Name" name="firstname" required /></td>
      </tr>
	  <tr>
	       <td><label>Last Name</label></td>
	       <td><input type="text" placeholder="Last Name" name="lastname" required /></td> 
      </tr>
	  <tr>
	       <td><label>Email</label></td>
	       <td><input type="email" placeholder="Email" name="email" required /></td> 
      </tr>
	  <tr>
	       <td><label>Mobile</label></td>
	       <td><input type="text" placeholder="Mobile Number" name="mobile" required /></td> 
      </tr>
	  <tr>
	      <td><label>City</label></td>
          <td><input type="text" placeholder="City" name="city" required /></td>
	  </tr>
	  <tr>
	       <td><label>State</label>
	       <td><input type="text" placeholder="State" name="state" required /></td>
	  </tr>
	  <tr>
	       <td><label>Country</label></td>
	       <td><input type="text" placeholder="Country" name="country" required /></td>
	  </tr>


      <tr>	  
      <td><label>Upload Image for Password</label></td>
	  <td><input type="file" name="image" accept="image/*" required /></td>
	  </tr>
	   <tr>	  
      <td><label>select any number</label></td>
	  <td><select id="covimg" name="covimg">
	  <option value="0.png">--select any number--</option>
	  <option value="1.png">1</option>
	  <option value="2.png">2</option>
	  <option value="3.png">3</option>
	  <option value="4.png">4</option>
	  <option value="5.png">5</option>
	  <option value="6.png">6</option>
	  <option value="7.png">7</option>
	  <option value="8.png">8</option>
	  <option value="9.png">9</option>
	  <option value="10.png">10</option>
	  </td>
	  </tr>
	 
	  <tr>
      <td><input type="submit" value="Register" name="register" class="btn btn-block btn-primary" /></td>
	  </tr>
	  <p><td>Already a member? <br/><a href="123.php">Sign in</a></td></p>
	</table>
	
    </form>
		</div>
</div
</body>
</html>


 <?php
	include("footer.php");
	?>   