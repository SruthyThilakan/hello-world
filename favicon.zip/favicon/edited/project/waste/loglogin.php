
<?php
$db= mysqli_connect("localhost","root","","2bank");
if(isset($_POST['login'])){

    $userid = mysqli_real_escape_string($db,$_POST['userid']);
    $password = mysqli_real_escape_string($db,$_POST['firstname']);

    if ($userid != "" && $password != ""){

        $sql_query = "select count(*) as cntUser from customer where userid='".$userid."' and password='".$password."'";
        $result = mysqli->query($db,$sql_query);
        $row = mysqli_fetch_array($result);

        $count = $row['cntUser'];

        if($count > 0){
            $_SESSION['uname'] = $userid;
            header('Location: index.php');
        }else{
            echo "Invalid username and password";
        }

    }

}
?>
<html>
<style>


/* Container */
.container{
    width:40%;
    margin:0 auto;
}

/* Login */
#div_login{
    border: 1px solid gray;
    border-radius: 3px;
    width: 470px;
    height: 270px;
    box-shadow: 0px 2px 2px 0px  gray;
    margin: 0 auto;
}

#div_login h1{
    margin-top: 0px;
    font-weight: normal;
    padding: 10px;
    background-color: cornflowerblue;
    color: white;
    font-family: sans-serif;
}

#div_login div{
    clear: both;
    margin-top: 10px;
    padding: 5px;
}

#div_login .textbox{
    width: 96%;
    padding: 7px;
}

#div_login input[type=submit]{
    padding: 7px;
    width: 100px;
    background-color: lightseagreen;
    border: 0px;
    color: white;
}
</style>
<body>
<link rel="stylesheet" href="frm.css" type="text/css">
<div class="body-content">
  <div class="module">
    <h1>Registered User Login</h1>
    <form class="form" action="login.php" method="post" enctype="multipart/form-data" autocomplete="off">
	
	 <table cellpadding="20" cellspacing="20" style="text-align:left;margin-left:0em" >
      
	  <tr>
	       <td><label>User ID</label></td>
           <td><input type="text" placeholder="UserID" name="userid" required /></td>
      </tr>
	  <tr>	  
      <td><div class="image"><label>Upload Image Password</label></td>
	  <td><input type="file" name="image" accept="image/*" required /></div></td>
	  </tr>
	  <tr>
      <td><input type="submit" value="Login" name="login" class="btn btn-block btn-primary" /></td>
	  </tr>
	  <p><td>New Registration  <a href="frm.php">Sign Up</a></td></p>
	</table>
    </form>
  </div>
</div
</body>
</html>
