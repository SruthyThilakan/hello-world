<?php
 session_start();
 include "header.php";
 $_SESSION['message']='';
  
	$db= mysqli_connect("localhost","root","","3bank");

 if($_SERVER['REQUEST_METHOD']== 'POST'){
	$userid=$db->real_escape_string($_POST['userid']);
    $image_path=$db->real_escape_string('image/secretimg.png');
    $covimg=$db->real_escape_string('image/covimg/'.$_POST['covimg']);
    if(preg_match("!image!",$_FILES['image']['type'])){		
        if(copy($_FILES['image']['tmp_name'],$image_path)){
            $python="C:\Users\SK\AppData\Local\Programs\Python\Python37-32\python";
            $img1 = $image_path;
            $img2 = $covimg;
            $output1 = 'image/share1.png';
            $output2 = 'image/shares/'.$userid.'s.png';
            $output3 = 'image/recsecret/'.$userid.'r.png';
            exec("$python python.py $img1 $img2 $output1 $output2 $output3"); #python sample.py img.jpg img2.jpg o.png oo.png
            header("Location: welcome.php");
        }
    }
 }
?>
<html>
<head>
    <title>Online Banking Registration</title>
</head>
<body>
<link rel="stylesheet" href="style.css" type="text/css">
<div class="body-content">
  <div class="module">
    <h1>Create an account</h1>
    <form class="form" action="reg5.php" method="post" enctype="multipart/form-data" autocomplete="off">
	<div class="alert alert-error"><?=$_SESSION['message'] ?></div>
	 <table cellpadding="20" cellspacing="20" style="text-align:left;margin-left:0em" >
      <div class="alert alert-error"></div>
      <tr>
	       <td><label>User ID</label></td>
           <td><input type="text" placeholder="Usern ID" name="userid" required /></td>
      </tr>

      <tr>	  
      <td><label>Upload Image for Password</label></td>
	  <td><input type="file" name="image" accept="image/*" required /></td>
	  </tr>
	   <tr>	  
      <td><label>select any number</label></td>
	  <td><select id="covimg" name="covimg">
	  <option value="0.png">--select any number--</option>
	  <option value="1.png">1</option>
	  <option value="2.png">2</option>
	  <option value="3.png">3</option>
	  <option value="4.png">4</option>
	  <option value="5.png">5</option>
	  <option value="6.png">6</option>
	  <option value="7.png">7</option>
	  <option value="8.png">8</option>
	  <option value="9.png">9</option>
	  <option value="10.png">10</option>
	  </td>
	  </tr>
	 
	  <tr>
      <td><input type="submit" value="Register" name="register" class="btn btn-block btn-primary" /></td>
	  </tr>
      </form>
	</div>
</div>
</body>
</html>