from PIL import Image, ImageChops
import sys
def xor(img1, img2, img3):
    
    image1 = Image.open(img1)
    image2 = Image.open(img2)
    image3 = Image.open(img3)
    result = ImageChops.logical_xor(image1,image2)
    result = ImageChops.invert(result)
    im3 = image3.load()
    result1 = result.load()

    images_match = True
    for i in range(0,600):
        for j in range(0,600):
            if(im3[i,j] != result1[i,j]):
                images_match = False

    return images_match

arg1 = str(sys.argv[1])
arg2 = str(sys.argv[2])
arg3 = str(sys.argv[3])
a = xor(arg1, arg2, arg3)
print(a)