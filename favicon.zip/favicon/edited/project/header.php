<?php
if(!isset($_SESSION["userid"])){
//session_start();
}
?>
<html>
<head>

<title>netbanking</title>

<link rel="stylesheet" href="newcss.css">
</head>
    <body>
        <div class="wrapper">
            
        <div class="header">
            <img src="header.jpg" height="100%" width="100%"/>
        </div>
        <?php
        if (isset($_SESSION["userid"]))
		{
		?>
		<link rel="stylesheet" href="style.css" type="text/css">
		<div class="navbar">
        <ul>
            <li><a href="accountalerts.php">My Account</a></li>
            <li><a href="transferfunds.php">Transfer funds</a></li>
            <li><a href="payloans.php">Pay loans</a></li>
            <li><a href="mailinbox.php">Mails</a></li>
            <li><a href="custprofile.php">Personalise</a></li>
            <li><a href="logout.php">logout</a></li>
        </ul>
		</div>
        <?php
		}
		else
		{
		?>
        <div class="navbar">
                
            <ul>
            <li><a href="index.php">Home </a></li>
            <li><a href="reg4.php">Register </a></li>
			<li><a href="1234.php">Login </a></li>
            <li><a href="features.php">Features </a></li>
			<li id="last"><a href="contact.php">Contact Us </a></li>
			</ul>
        </div>
            <?php
           }    
           ?>
        
</body>
</html>