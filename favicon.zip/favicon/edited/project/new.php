<!DOCTYPE html>
<html lang="en">
<body>
 <form action="" method="post" enctype="multipart/form-data">
<tr>
                  <td>User Name</td>
                  <td><input type="text" name="cname" value="" size="16" onkeyup="isalphanum(this)"/></td>

              </tr>

<tr>
                  
 select image password to login
<input type="file" name="image"/>
<input type ="submit" name="submit" value="UPLOAD" />
</tr>
</form>

<?php

session_start();
include("header.php");
include("dbconnection.php");
if(isset($_SESSION["customerid"]))
{
header("Location: accountalerts.php");
 $check = getimagesize($_FILES["image"]["tmp_name"]);
   
if($check !==FALSE)   {
$image = $_FILES['image'] ['tmp_name'];
$imgContent = addslashes(file_get_contents($image));
if(isset($_POST["login"])){
 $username=$_POST["login"];
 $image=$_POST["image"]
}
else
{
 $username="";
 $password="";
}
}
$flag=0;

$result = mysqli_query($connection,"SELECT * FROM customers WHERE loginid='$username'");
$_SESSION["accpassword"] = 	$recarr["accpassword"];

$recarr = mysqli_fetch_array($result)
$image2= $recarr["image"];
$img2Content = addslashes(file_get_contents($image2));	
if(mysqli_num_rows($result) == 1 and '$img2Content' ='$imgContent'){
	
		
		$_SESSION["userid"] = 	$recarr["userid"];

	
		$_SESSION["customername"] = 	$recarr["firstname"]. " ". $recarr["lastname"];
		$_SESSION["loginid"] = 	$recarr["loginid"];
		$_SESSION["city"] = 	$recarr["city"];
		$_SESSION["state"] = 	$recarr["state"];
		$_SESSION["country"] = 	$recarr["country"];
		}
		$_SESSION[loginid] =$_POST[login];
		header("Location: accountalerts.php");
	}
	else
	{
		$logininfo = "Invalid Username or password entered";
	}	
	
	?>
	</body>
</html>
	<?php
	include("footer.php");
	?>