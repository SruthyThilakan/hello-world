<?php
session_start();
include("header.php");
include("dbconnection.php");
$dts = date("Y-m-d h:i:s");
$customer_session=$_SESSION["userid"];
//mysqli_query("UPDATE customer SET lastlogin='$dts' WHERE customerid='$customer_session'");
$sqlq = mysqli_query($connection, "select * from transaction where paymentstat='Pending'");
$mailreq = mysqli_query($connection, "select * from mail");
$ifsccode = $_SESSION["ifsccode"];
$result = mysqli_query($connection,"select branchname from branch WHERE ifsccode='$ifsccode'");
$row=mysqli_fetch_array($result);
$_SESSION["branchname"] = 	$row["branchname"];
?>
<html>


<div id="templatemo_main"><span class="main_top"></span> 
     	
<div id="templatemo_content">
     		 <h2>Alerts and messages</h2>
     		 <table width="548" border="0">
     		   <tr>
     		     <th colspan="2" scope="col">Alerts</th>
   		       </tr>
     		   <tr>
     		     <td width="293">Customer Name</td>
     		     <td width="245"><?php echo $_SESSION["customername"]; ?></td>
   		     </tr>
     		   <tr>
     		     <td>Branch name</td>
     		     <td>&nbsp;<?php echo $_SESSION["branchname"];?></td>
   		     </tr>
     		   <tr>
     		     <td>User logged on</td>
     		     <td><?php echo $dts; ?> </td>
   		     </tr>
     		   <tr>
     		     <td>Pending payments</td>
     		     <td><?php echo mysqli_num_rows($sqlq); ?></td>
   		     </tr>
     		   <tr>
     		     <td>Unread mails</td>
     		     <td><?php echo mysqli_num_rows($mailreq); ?></td>
   		     </tr>
   		   </table>
     		 <p>&nbsp;</p>
     <p>&nbsp;</p>
        
        <div class="cleaner_h30"></div>
  <div class="cleaner_h60"></div>
</div><!-- end of content -->
            
            <div id="templatemo_sidebar">
            
            <?php
	   include("myaccountssidebar.php");
	   ?>
              <div class="cleaner_h40"></div>
    </div>
                
		<div class="cleaner"></div>
     </div>     <!-- end of main -->
    <div id="templatemo_main_bottom"></div><!-- end of main -->
</div>    
    <?php
	include("footer.php");
	?>