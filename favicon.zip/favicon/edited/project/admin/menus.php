<nav id="primary_nav_wrap">
<ul>
 
  <li><a href="#">Users</a>
    <ul>
      <li><a href="usermng.php" alt="Manage Users" title="This takes you to User Management Section">Manage users</a></li>
       
          </li>
          
    </ul>
  </li>
  
  <li><a href="#">Student</a>
    <ul>
        <li><a href="studentmng.php" alt="Manage Students" title="Student Management">Generate Auto ID</a></li>
      
    </ul>
  </li>  
 
</nav>