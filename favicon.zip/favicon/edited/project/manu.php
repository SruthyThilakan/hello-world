<?php
session_start();
include("header.php");
include("dbconnection.php");
$logininfo="";
$check="FALSE";
if(isset($_SESSION["userid"]))
{
    header("Location: accountalerts.php");
}

if(isset($_POST["login"])){
  $userid=$connection->real_escape_string($_POST['userid']);
    
  $check = getimagesize($_FILES["image"]["tmp_name"]);
  if($check !==FALSE)   {
    $image_path = $_FILES['image'] ['tmp_name'];
$name = $_FILES['image']['name'];

  
  $imgContent = file_get_contents($image_path ,TRUE );
  
  
  $query=$connection->query("SELECT * FROM customer WHERE userid='$userid'");	
  if($query===FALSE){
    die(mysqli_error());
  }
  while($row=mysqli_fetch_array($query))
      {
        $imagedb= $row["image"];
        
      $imgdbContent = file_get_contents($imagedb);

      if($imgContent == $imgdbContent){
        $_SESSION[userid] =$_POST[userid];
        header("Location: accountalerts.php");
      
      $_SESSION["userid"] = 	$row["userid"];    
      
     
      $_SESSION["customername"] = 	$row["firstname"]. " ". $row["lastname"];
       
    }
    else
    {
      $logininfo = "Invalid username or  password entered!!!";
    }
  
  }
}

  else
{
  $logininfo = "select an image!!!!";
}

 

  }
 
	




?>

<html>
<link rel="stylesheet" href="style.css" type="text/css">

                                    <h2>please note</h2><br/>
                                    <p>You should know how to operate net transaction and if you are not familiar you may refrain from doing so. You may seek banks guidance in this regard. Bank is not responsible for online transactions going wrong</p>
                                    <br/>
                                  
                               	
     <p class="welcome_text">&quot;<strong>Login page:<br /> 
       Please enter user id and password to login</strong>&quot;</p>
     <p class="welcome_text"><br />
     <?php
	 echo $logininfo;
	 ?>
     </p>
         <div class="body-content">
         <div class="module">
       
            <h1>Registered User Login</h1>
            <form class="form" action="manu.php" method="post" enctype="multipart/form-data" autocomplete="off">
	
            <table  cellpadding="20" cellspacing="20" style="text-align:left;margin-left:0em" >
      
	        <tr>
	            <td><label>User ID</label></td>
                <td><input type="text" placeholder="UserID" name="userid" required /></td>
            </tr>	  
        
           
            <tr>  
                <td><label>Upload Image Password</label></td>
	            <td><input type="file" name="image"  required /></td>
            </tr>
	        <tr>
                <td><input type="submit" value="Login" name="login" class="btn btn-block btn-primary" /></td>
            </tr>
           
	        <p><td>New Registration<br/>
                <a href="frm.php">Sign Up</a></td></p>
            </table>
            
           </form>
     </div>  
        
</div>
     	
 </html>



