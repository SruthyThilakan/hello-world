<nav id="primary_nav_wrap">
<ul>
  
  <li><a href="#">Exam</a>
    <ul>
      <li><a href="searchdept.php" alt="Manage Exam" title="This takes you to Exam Management Section">Manage Exam</a></li>
       
          </li>
          
    </ul>
  </li>
  <li><a href="#">Results</a>
    <ul>
      <li><a href="rsltmng.php" alt="Manage Test Results" title="Click this to view Test Results.">Manage Results</a></li>
      
    </ul>
  </li>
  <li><a href="#">Assessment</a>
    <ul>
      <li><a href="underconstruction.php">Manage Assessment</a></li>
      
    </ul>
  </li>
  <li><a href="#">Grade</a>
    <ul>
      <li><a href="underconstruction.php">Manage Grade</a></li>
      
    </ul> 
     <li><a href="#">Account</a>
    <ul>
      <li><a href="changepass.php?edit=edit" alt="Edit Your Password" title="This takes you to Edit Password Section">Change Password</a></li>
      
    </ul> 
  </li>
</nav>