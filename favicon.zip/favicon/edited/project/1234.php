<?php
session_start();
include("header.php");
include("dbconnection.php");
$logininfo="";
$check="FALSE";
$db = mysqli_connect("localhost","root","","3bank");
if(isset($_SESSION["userid"]))
{
    header("Location: accountalerts.php");
}

if(isset($_POST["login"])){
  $userid=$db->real_escape_string($_POST['userid']);
  $share1='image/loginimg.png';
  $check = getimagesize($_FILES["image"]["tmp_name"]);
  if($check !==FALSE)   {
    if(copy($_FILES['image']['tmp_name'],$share1)){
    $query=$connection->query("SELECT * FROM customer WHERE userid='$userid'");	
    $cnt=$connection->query("SELECT  count (*)  FROM customer WHERE userid='$userid'");	
    if($cnt ===0 ){
        $logininfo = "Invalid username  entered!!!";
  
        die(mysqli_error());
      }
    else{
      while($row=mysqli_fetch_array($query))
      {
        $share2= $row["share1"];
        $result= $row["recimg"];
    
    $python="C:\Users\Sruthy T\AppData\Local\Programs\Python\Python37-32\python";
    $c = shell_exec("$python xor.py $share1 $share2 $result");

      if($c == True){
      
 
        
      
      $_SESSION["userid"] = 	$row["userid"];        
     
      $_SESSION["customername"] = 	$row["firstname"]. " ". $row["lastname"];

      $_SESSION["ifsccode"] =   $row["ifsccode"];
      header("Location: accountalerts.php");
      
         
    }
  
  else
  {
    $logininfo = "Invalid password entered!!!";
  }
}
  }
   
  
  }

}

else
{
  $logininfo = "select an image!!!!";
}
}


?>

<html>
<link rel="stylesheet" href="style.css" type="text/css">
    
    <div id="templatemo_banner">
    
    			<span class="nav_bg"></span>
            
                <div id="one" class="contentslider">
                    <div class="cs_wrapper">
                        <div class="cs_slider">
                                                  
                            <div class="cs_article">
                            
                            <div class="slider_content_wrapper">
                                
                         		 <div class="right">
                                    <h2>please note</h2><br/>
                                    <p>You should know how to operate net transaction and if you are not familiar you may refrain from doing so. You may seek banks guidance in this regard. Bank is not responsible for online transactions going wrong</p>
                                    <br/><br/>
                                  
                               	</div>
                                </div>
                                
                            </div><!-- End cs_article -->
                      
                        </div><!-- End cs_slider -->
                    </div><!-- End cs_wrapper -->
                </div><!-- End contentslider -->
                
                
   
        </div>
     
     
     <p class="welcome_text">&quot;<strong>Login page:<br />
       Please enter user id and password to login</strong>&quot;</p>
     <p class="welcome_text"><br />
     <?php
	 echo $logininfo;
	 ?>
     </p>
     
     	<div class="body-content">
     

     <div class="module">
    <h1>Registered User Login</h1>
    <form class="form" action="1234.php" method="post" enctype="multipart/form-data" autocomplete="off">
	
	 <table cellpadding="20" cellspacing="20" style="text-align:left;margin-left:0em" >
      
	  <tr>
	       <td><label>User ID</label></td>
           <td><input type="text" placeholder="UserID" name="userid" required /></td>
      </tr>
	  <tr>	  
      <td><label>Upload Image Password</label></td>
	  <td><input type="file" name="image"  required /></td>
	  </tr>
	  <tr>
      <td><input type="submit" value="Login" name="login" class="btn btn-block btn-primary" /></td>
	  </tr>
	  <p><td>New Registration <br/>
       <a href="frm.php">Sign Up</a></td></p>
	</table>
    </form>
  </div>

        
</div>
     	
 </html>
 <?php
	include("footer.php");
	?>   
