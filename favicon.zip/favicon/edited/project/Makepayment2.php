<?php
session_start();
include("header.php");
include("dbconnection.php");
if(isset($_POST['pay']))
{
$payto = '$_POST[payto]';
$payamt = '$_POST[payamt]';
$payacno= '$_POST[accountnumber]';
}

$result = mysqli_query($connection,"select * from registerdpayee WHERE userid='$_SESSION[userid]'");

$result1 = mysqli_query($connection,"select * from registerdpayee WHERE userid='$payto'");
$arrpayment = mysqli_fetch_array($result1);

$dt = date("Y-m-d h:i:s");

$resultpass = mysqli_query($connection,"select * from customers WHERE customerid='$_SESSION[userid]'");
$arrpayment1 = mysqli_fetch_array($resultpass);
$passerr = "";
		
if(isset($_POST["pay2"]))
{
    
	if($_POST[trpass] == $arrpayment1[trans_password])
	{
		$sql="INSERT INTO transaction(transactionid,transactiondate,paymentdate,payeeid,receiveid,debitac,amount,paymentstat)
		VALUES ('$_POST[transactionid]','$_POST[transactiondate]','$_POST[paymentdate]','$_POST[payeeid]', '$_POST[receiveid]','$_POST[debitac]','$_POST[payamt]','$_POST[paymentstat]')";
				if (!mysqli_query($sql,$connection))
				  {
				  die('Error: ' . mysqli_error());
				  }
				if(mysqli_affected_rows() == 1)
				  {
					$successresult = "Transaction successfull";
					header("Location: Makepayment3.php");
				  }
				else
				  {
					  $successresult = "Failed to transfer";
				  }
	}
	else
	{
	$passerr = "<b>Invalid password entered...<br> Please re-enter transaction password</b>";
	$payto = $_POST[paytoo];
	$payamt = $_POST[payamt];
	$payacno= $_POST[payeeid];
	}		  
}


$acc= mysqli_query($connection,"select * from accounts where userid='$_SESSION[userid]'");

?>
    
    
     <div id="templatemo_main"><span class="main_top"></span> 
     	
        <div id="templatemo_content">
                
        	<form id="form1" name="form1" method="post" action="Makepayment2.php">
  

      
     	<h2>&nbsp;Make paymentvt to <?php echo $arrpayment["payeename"]; ?></h2>
              <table width="564" height="220" border="1">
                <?php
				if($passerr!= "")
				{
					?>
                <tr>
                  <td colspan="2">&nbsp;<?php echo $passerr; ?></td>
                </tr>
                <?php
				}
				?>
                <tr>
                  <td width="203"><strong>Pay to</strong></td>
                  <td width="322">
				  <?php
				echo "<tr>
				<td>&nbsp;Payee Name : </td>.$arrpayment[payeename];
				 <td>&nbsp;Account No. : </td>.$arrpayment[accountnumber];
				<td>&nbsp;Account type : </td>.$arrpayment[accounttype];
				<td>&nbsp;Bank name : </td>.$arrpayment[bankname];
				<td>&nbsp;IFSC Code : </td>.$arrpayment[ifsccode];
                 </tr>;"	
                  ?>
                  
<input type="hidden" name="paytoo" value="<?php echo $payto; ?>"  />
<input type="hidden" name="amt" value="<?php echo $payamt; ?>"  />
<input type="hidden" name="payeeid" value="<?php echo $payacno; ?>"  />
				  </td>
                </tr>
                <tr>
                  <td><strong>Payment amount</strong></td>
                  <td>&nbsp;<?php echo number_format((float)$payamt,2); ?></td>
                </tr>
                <tr>
                  <td><strong>Account number</strong></td>
                  <td>&nbsp;<?php echo $payacno; ?></td>
                </tr>
                <tr>
                  <td><strong>Enter Transaction Password</strong></td>
                  <td><input name="trpass" type="password" id="trpass" size="35" /></td>
                </tr>
                <tr>
                  <td><strong>Confirm Password</strong></td>
                  <td><input name="conftrpass" type="password" id="conftrpass" size="35" /></td>
                </tr>
                <tr>
                  <td colspan="2"><div align="right">
                    <input type="submit" name="pay2" id="pay2" value="Pay" />
                    <input name="button" type="button" onclick="<?php echo "window.location.href='alerts.php'"; ?>" value="Cancel" alt="Pay Now" />
                  </div></td>
                </tr>
              </table>
  

<p>&nbsp;</p>
        	  <p>&nbsp;</p>
       	  </form>
<div class="cleaner_h50"></div>
        </div><!-- end of content -->
            
            <div id="templatemo_sidebar">
            
                <?php
				include("custsidebar.php");
				transferfunds();
				?>
              <div class="cleaner_h40"></div>
                
                <h2>&nbsp;</h2>
</div>
                
		<div class="cleaner"></div>
     </div>     <!-- end of main -->
    <div id="templatemo_main_bottom"></div><!-- end of main -->
    
    <?php
include("footer.php");
?>