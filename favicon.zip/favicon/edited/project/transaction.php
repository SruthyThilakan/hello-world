<?php
include("header.php");
?>
<div id="templatemo_main"><span class="main_top"></span> 
     	
<div id="templatemo_content">
  <h2 align="center">TRANSACTIONSMADE</h2>
         
              <table width="578" border="1">
                 <tr>
                   <th width="48" scope="col"><div align="center">SLNO</div></th>
                   <th width="80" scope="col"><div align="center">DATE</div></th>
                   <th width="110" scope="col"><div align="center">DESCRIPTION</div></th>
                   <th width="125" scope="col"><div align="center">WITHDRAWALS</div></th>
                   <th width="181" scope="col"><div align="center">DEPOSITS</div></th>
                   </tr>
                 <tr>
                   <td height="27"><div align="center">1</div></td>
                   <td><div align="center">26-12-2010</div></td>
                   <td><div align="center">CHARGE</div></td>
                   <td><div align="center">100RS</div></td>
                   <td><div align="center"></div></td>
                   </tr>
                 <tr>
                   <td><div align="center">2</div></td>
                   <td><div align="center">25-11-2011</div></td>
                   <td><div align="center">PAID BILL</div></td>
                   <td><div align="center"></div></td>
                   <td><div align="center">5000</div></td>
                   </tr>
                 <tr>
                   <td><div align="center">3</div></td>
                   <td><div align="center">23-10-2011</div></td>
                   <td><div align="center">PAID BILL</div></td>
                   <td><div align="center">500RS</div></td>
                   <td><div align="center"></div></td>
                   </tr>
                 <tr>
                   <td><div align="center">4</div></td>
                   <td><div align="center">23-09-2011</div></td>
                   <td> <div align="center">PAID BILL</div></td>
                   <td><div align="center">1000RS</div></td>
                   <td><div align="center"></div></td>
                   </tr>
                 <tr>
                   <td><div align="center">5</div></td>
                   <td><div align="center">23-01-2011</div></td>
                   <td><div align="center">PAID BILL</div></td>
                   <td><div align="center"></div></td>
                   <td><div align="center">500RS</div></td>
                   </tr>
                 <tr>
                   <td><div align="center">6</div></td>
                   <td><div align="center">23-08-2011</div></td>
                   <td><div align="center">PAID BILL</div></td>
                   <td><div align="center">500RS</div></td>
                   <td><div align="center"></div></td>
                   </tr>
                 <tr>
                   <td><div align="center">7</div></td>
                   <td><div align="center">23-07-2011</div></td>
                   <td><div align="center">PAID BILL</div></td>
                   <td><div align="center"></div></td>
                   <td><div align="center">100RS</div></td>
                   </tr>
                 <tr>
                   <td><div align="center">8</div></td>
                   <td><div align="center">13-10-2011</div></td>
                   <td><div align="center">PAID BILL</div></td>
                   <td><div align="center"></div></td>
                   <td><div align="center">600RS</div></td>
                   </tr>
                 <tr>
                   <td><div align="center">9</div></td>
                   <td><div align="center">20-10-2011</div></td>
                   <td><div align="center">PAID BILL</div></td>
                   <td><div align="center">250RS</div></td>
                   <td><div align="center"></div></td>
                   </tr>
                 <tr>
                   <td><div align="center">10</div></td>
                   <td><div align="center">21-11-2012</div></td>
                   <td><div align="center">PAID BILL</div></td>
                   <td><div align="center"></div></td>
                   <td><div align="center">300RS</div></td>
                   </tr>
           </table>
      
         <p>&nbsp;</p>
        
        <div class="cleaner_h30"></div>
  <div class="cleaner_h60"></div>
</div><!-- end of content -->
            
            <div id="templatemo_sidebar">
            
       <?php
	   include("myaccountssidebar.php");
	   ?>
                

                
                <div class="cleaner_h40"></div>
                
                <h2>Testimonial</h2>
                <blockquote>
                <p>In ac libero urna. Suspendisse sed odio ut mi auctor blandit. Duis luctus nulla metus. Validate <a href="http://validator.w3.org/check?uri=referer" rel="nofollow"><strong>XHTML</strong></a> &amp; <a href="http://jigsaw.w3.org/css-validator/check/referer" rel="nofollow"><strong>CSS</strong></a>.</p>
                
                <cite>David - <span>Web Specialist</span></cite>
                </blockquote>
            
            </div>
                
		<div class="cleaner"></div>
     </div>     <!-- end of main -->
    <div id="templatemo_main_bottom"></div><!-- end of main -->
    
    <?php
	include("footer.php");
	?>