<div id="templatemo_sidebar">
            
                <h2>Mails</h2>
                
                <ul class="templatemo_list">
                <li><a href="mailinbox.php"><strong>Inbox</strong></a></li>
                <li><strong><a href="mailcompose.php">Compose</a></strong></li>
                <li><strong><a href="mailsent.php">Sent mail</a></strong><a href="mailsent.php"></a></li>
  </ul>
              <div class="cleaner_h40"></div>
    </div>