<nav id="primary_nav_wrap">
<ul>
  
  <li><a href="#">Exam</a>
    <ul>
    <li><a href="practicetest.php" alt="Practice Test" title="Practice Test">Practice Test</a></li>
      <li><a href="stdexam.php" alt="Take a New Exam" title="Take a New Exam">Take Exam</a></li>
       
          </li>
          
    </ul>
  </li>
  <li><a href="#">Results</a>
    <ul>
      <li><a href="viewresult.php" alt="View Results" title="Click to View Results">View Results</a></li>
      
    </ul>
  </li>
  <!--
  <li><a href="#">Assessment</a>
    <ul>
      <li><a href="#">Manage Assessment</a></li>
      
    </ul>
  </li>
  <li><a href="#">Grade</a>
    <ul>
      <li><a href="#">Manage Grade</a></li>
      
    </ul>
    -->
     <li><a href="#">Account</a>
    <ul>
      <li><a href="changepass.php?edit=edit" alt="Edit Your Password" title="This takes you to Edit Password Section">Change Password</a></li>
      
    </ul> 
  </li>
</nav>