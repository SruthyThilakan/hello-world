<?php
    $connection = mysqli_connect("localhost","root","","3bank");
?>