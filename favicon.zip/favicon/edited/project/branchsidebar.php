         <h2> Settings sidebar</h2>
                
                <ul class="templatemo_list">
                <li>Account Master</li>
                <li>Branch</li>
                <li>Loan type</li>
        </ul>