-- phpMyAdmin SQL Dump
-- version 4.1.14
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: Apr 28, 2019 at 11:48 AM
-- Server version: 5.6.17
-- PHP Version: 5.5.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `3bank`
--

-- --------------------------------------------------------

--
-- Table structure for table `accountmaster`
--

CREATE TABLE IF NOT EXISTS `accountmaster` (
  `accounttype` varchar(25) NOT NULL,
  `prefix` varchar(11) NOT NULL,
  `minbalance` double(12,2) NOT NULL,
  `interest` double(10,2) NOT NULL,
  PRIMARY KEY (`accounttype`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `accountmaster`
--

INSERT INTO `accountmaster` (`accounttype`, `prefix`, `minbalance`, `interest`) VALUES
('current', 'fd', 6000.00, 600.00),
('dfd', 'gdf', 45.00, 7546.00),
('salary account', 'SAL', 0.00, 10.00),
('saving', 'sb', 4000.00, 500.00);

-- --------------------------------------------------------

--
-- Table structure for table `accounts`
--

CREATE TABLE IF NOT EXISTS `accounts` (
  `accno` varchar(25) NOT NULL,
  `userid` varchar(50) NOT NULL,
  `accstatus` varchar(25) NOT NULL,
  `primaryacc` varchar(10) NOT NULL,
  `accopendate` date NOT NULL,
  `accounttype` varchar(25) NOT NULL,
  `accountbalance` double(10,2) NOT NULL,
  `unclearbalance` double(10,2) NOT NULL,
  `accuredinterest` double(10,2) NOT NULL,
  PRIMARY KEY (`accno`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `accounts`
--

INSERT INTO `accounts` (`accno`, `userid`, `accstatus`, `primaryacc`, `accopendate`, `accounttype`, `accountbalance`, `unclearbalance`, `accuredinterest`) VALUES
('4666', 'manu123', 'active', '40000', '2013-02-11', 'sv', 100000.00, 100.00, 100.00);

-- --------------------------------------------------------

--
-- Table structure for table `branch`
--

CREATE TABLE IF NOT EXISTS `branch` (
  `ifsccode` varchar(25) NOT NULL,
  `branchname` varchar(50) NOT NULL,
  `city` varchar(25) NOT NULL,
  `branchaddress` text NOT NULL,
  `state` varchar(25) NOT NULL,
  `country` varchar(25) NOT NULL,
  PRIMARY KEY (`ifsccode`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `branch`
--

INSERT INTO `branch` (`ifsccode`, `branchname`, `city`, `branchaddress`, `state`, `country`) VALUES
('KARB0000404', 'karkala', 'karkala', 'NEAR BUS STAND,KARLA COMPLEX,1ST FLOOR,PB 19,KARKALA 574104,UDUPI DIST', 'KARNATAKA', 'india'),
('sbi1234567', 'edappal', 'palakkad', 'ZAXXAFAERGR', 'kerala', 'india'),
('sbi12345678', 'edappal', 'palakkad', 'ZAXXAFAERGR', 'kerala', 'india'),
('sbi1234567q2', 'Mangalore', 'gfhdh', 'hdjjj', 'PAKISTAN', 'MAHARASTRA'),
('tyg', 'yfy', 'fy', 'yfg', 'PAKISTAN', 'MAHARASTRA');

-- --------------------------------------------------------

--
-- Table structure for table `customer`
--

CREATE TABLE IF NOT EXISTS `customer` (
  `userid` varchar(50) NOT NULL,
  `firstname` varchar(50) NOT NULL,
  `lastname` varchar(50) NOT NULL,
  `city` varchar(50) NOT NULL,
  `state` varchar(50) NOT NULL,
  `country` varchar(50) NOT NULL,
  `image` varchar(100) NOT NULL,
  `lastlogin` datetime NOT NULL ON UPDATE CURRENT_TIMESTAMP,
  `ifsccode` varchar(50) NOT NULL,
  `accstatus` varchar(50) NOT NULL,
  `email` varchar(100) NOT NULL,
  `mobile` int(10) NOT NULL,
  PRIMARY KEY (`userid`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `customer`
--

INSERT INTO `customer` (`userid`, `firstname`, `lastname`, `city`, `state`, `country`, `image`, `lastlogin`, `ifsccode`, `accstatus`, `email`, `mobile`) VALUES
('anjitha98', 'anjitha', 'hv', 'pallakkad', 'kerala', 'india', 'image/images (5).jpeg', '2019-04-01 18:37:13', '1234567890', '', 'email', 0),
('anu98', 'anu', 'sree', 'calicut', 'kerala', 'India', 'image/Untitled.jpg', '2019-04-01 10:27:30', '1234567890', '', '', 0),
('athira96', 'athira', 'balachandran', 'kannur', 'kerala', 'india', 'image/index.jpg', '2019-04-01 11:39:02', '12345667888', '', '', 0),
('fathima98', 'fathima', 'thasneem', 'Malappuram', 'nilfhwi', 'kjnfiugws', 'image/India-clock_&_24f2493b-903f-4e6c-b785-b9dc307e187e.jpg', '2019-04-01 19:38:04', '2456667778888', '', 'email', 0),
('indu97', 'indu', 'p', 'kunnanmkulam', 'kerala', 'India', 'image/images-68.jpeg', '2019-04-01 12:12:36', '123456789900', '', 'email', 0),
('maneeshank98', 'maneesha', 'nk', 'palakkad', 'kerala', 'india', 'image/India-cello_&_7d53eca2-055c-45b1-80bc-2aa68e4310b4.jpg', '2019-04-01 10:52:50', '', '', '', 0),
('manu123', 'maneesha', 'nk', 'palakkad', 'kerala', 'india', 'image/athi.jpg', '2019-04-01 18:50:58', 'sbi1234567', '', 'maneeshank98@gmail.com', 2147483647),
('sajitha97', 'sajitha', 'kk', 'manjeri', 'kerala', 'india', 'image/images-68.jpeg', '2019-04-01 11:34:13', '1233455678', '', '', 0),
('sruthy98', 'sruthy', 'thilakan', 'thrissur', 'kerala', 'india', 'image/index1.jpg', '2019-04-01 11:36:27', '9539814639', '', '', 0);

-- --------------------------------------------------------

--
-- Table structure for table `customers`
--

CREATE TABLE IF NOT EXISTS `customers` (
  `customerid` int(10) NOT NULL AUTO_INCREMENT,
  `ifsccode` varchar(25) NOT NULL,
  `firstname` varchar(25) NOT NULL,
  `lastname` varchar(25) NOT NULL,
  `loginid` varchar(25) NOT NULL,
  `accpassword` varchar(50) NOT NULL,
  `transpasword` varchar(50) NOT NULL,
  `accstatus` varchar(25) NOT NULL,
  `city` varchar(25) NOT NULL,
  `state` varchar(25) NOT NULL,
  `country` varchar(25) NOT NULL,
  `accopendate` date NOT NULL,
  `lastlogin` datetime NOT NULL,
  `image` varchar(100) NOT NULL,
  PRIMARY KEY (`customerid`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=98684 ;

--
-- Dumping data for table `customers`
--

INSERT INTO `customers` (`customerid`, `ifsccode`, `firstname`, `lastname`, `loginid`, `accpassword`, `transpasword`, `accstatus`, `city`, `state`, `country`, `accopendate`, `lastlogin`, `image`) VALUES
(98680, 'KARB0000404', 'sadf', 'werwe', '23432', 'fgdfg', 'werwe', 'ACTIVE', '23423', 'KARNATAKA', 'INDIA', '2013-02-02', '0000-00-00 00:00:00', ''),
(98682, '5249898', 'Raj', 'kiran', '123456', '1552051463_tmp_Sign__1_.jpg', '123456', 'ACTIVE', 'mangaloree', 'KARNATAKA', 'INDIA', '2013-02-02', '0000-00-00 00:00:00', ''),
(98683, '5249898', 'john', 'mark', 'cust', 'cust', 'cust', 'ACTIVE', 'mangalore', 'KARNATAKA', 'INDIA', '2013-02-09', '2013-02-16 05:25:20', '');

-- --------------------------------------------------------

--
-- Table structure for table `employees`
--

CREATE TABLE IF NOT EXISTS `employees` (
  `empid` int(10) NOT NULL AUTO_INCREMENT,
  `employee_name` varchar(25) NOT NULL,
  `loginid` varchar(25) NOT NULL,
  `password` varchar(25) NOT NULL,
  `emailid` varchar(30) NOT NULL,
  `contactno` varchar(30) NOT NULL,
  `createdat` date NOT NULL,
  `last_login` datetime NOT NULL,
  PRIMARY KEY (`empid`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=313800 ;

--
-- Dumping data for table `employees`
--

INSERT INTO `employees` (`empid`, `employee_name`, `loginid`, `password`, `emailid`, `contactno`, `createdat`, `last_login`) VALUES
(313786, 'soudhabanu', '445545', '125487', 'soudha_ban@52yahoo.com', '9535543313', '2012-12-15', '2012-12-03 11:27:00'),
(313787, 'mahesh', 'mahesh', 'qwert', 'mahesh@gmail.com', '98478872783', '0000-00-00', '0000-00-00 00:00:00'),
(313788, 'jyothi', '3535355', '3636', 'jyothi@yahoo.com', '95425422424', '2013-01-02', '0000-00-00 00:00:00'),
(313791, 'admin', 'admin', 'admin', 'admin', 'admin', '2013-01-12', '2013-01-12 00:00:00'),
(313798, 'raj', 'rajkiran', '123456', 'abc@gmail.com', '9874563210', '2013-02-02', '0000-00-00 00:00:00'),
(313799, 'peter king', 'emp', 'emp', 'emp@gmail.com', '987456321', '2013-02-09', '0000-00-00 00:00:00');

-- --------------------------------------------------------

--
-- Table structure for table `loan`
--

CREATE TABLE IF NOT EXISTS `loan` (
  `loanid` int(10) NOT NULL AUTO_INCREMENT,
  `loantype` varchar(25) NOT NULL,
  `loanamt` varchar(25) NOT NULL,
  `period` varchar(25) NOT NULL,
  `interest` float(10,2) NOT NULL,
  `startdate` date NOT NULL,
  PRIMARY KEY (`loanid`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=2147483647 ;

--
-- Dumping data for table `loan`
--

INSERT INTO `loan` (`loanid`, `loantype`, `loanamt`, `period`, `interest`, `startdate`) VALUES
(2147483647, 'homeloan', '300000', 'monthly', 63.09, '2012-12-02');

-- --------------------------------------------------------

--
-- Table structure for table `loanpayment`
--

CREATE TABLE IF NOT EXISTS `loanpayment` (
  `paymentid` int(10) NOT NULL AUTO_INCREMENT,
  `date` date NOT NULL,
  `paidamt` float(10,2) NOT NULL,
  `principleamt` float(10,2) NOT NULL,
  `interestamt` float(10,2) NOT NULL,
  `balance` float(10,2) NOT NULL,
  PRIMARY KEY (`paymentid`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=2147483647 ;

--
-- Dumping data for table `loanpayment`
--

INSERT INTO `loanpayment` (`paymentid`, `date`, `paidamt`, `principleamt`, `interestamt`, `balance`) VALUES
(2147483647, '2012-01-03', 50000.00, 25000.00, 2500.50, 250000.00);

-- --------------------------------------------------------

--
-- Table structure for table `loantype`
--

CREATE TABLE IF NOT EXISTS `loantype` (
  `loantype` varchar(25) NOT NULL,
  `prefix` varchar(25) NOT NULL,
  `maximumamt` float(10,2) NOT NULL,
  `minimumamt` float(10,2) NOT NULL,
  `interest` float(10,2) NOT NULL,
  `status` varchar(25) NOT NULL,
  UNIQUE KEY `loantype` (`loantype`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `loantype`
--

INSERT INTO `loantype` (`loantype`, `prefix`, `maximumamt`, `minimumamt`, `interest`, `status`) VALUES
('current', 'sb', 70000.00, 50000.00, 3000.00, 'active'),
('homeloan', 'hl', 1000000.00, 50000.00, 65.09, 'active'),
('sb', 'fd', 7000.00, 5000.00, 400.00, 'active');

-- --------------------------------------------------------

--
-- Table structure for table `mail`
--

CREATE TABLE IF NOT EXISTS `mail` (
  `mailid` int(10) NOT NULL AUTO_INCREMENT,
  `subject` varchar(250) NOT NULL,
  `message` text NOT NULL,
  `mdatetime` datetime NOT NULL,
  `senderid` varchar(25) NOT NULL,
  `reciverid` varchar(25) NOT NULL,
  PRIMARY KEY (`mailid`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=25 ;

--
-- Dumping data for table `mail`
--

INSERT INTO `mail` (`mailid`, `subject`, `message`, `mdatetime`, `senderid`, `reciverid`) VALUES
(10, 'sdfgfdg', 'dfgfdg', '2013-01-19 05:05:58', '0', 'admin'),
(12, 'fdgdfsgsd', 'fgdsfgdsfg', '2013-02-02 05:32:29', 'admin', '98682'),
(13, 'hello this is test pag', 'this is test page to all emp', '2013-02-02 05:33:00', 'admin', '98682'),
(14, 'good morning raj kiran', 'this is welcome page', '2013-02-02 05:36:16', 'admin', '98682'),
(15, 'CVFG', 'FFASAS', '0000-00-00 00:00:00', 'manu123', ''),
(16, 'CVFG', 'FFASAS', '0000-00-00 00:00:00', 'manu123', ''),
(17, 'CVFG', 'FFASAS', '0000-00-00 00:00:00', 'manu123', ''),
(18, 'CVFG', 'FFASAS', '0000-00-00 00:00:00', 'manu123', ''),
(19, 'CVFG', 'FFASAS', '0000-00-00 00:00:00', 'manu123', ''),
(20, 'CVFG', 'FFASASvjksjdsjf', '0000-00-00 00:00:00', 'manu123', ''),
(21, 'CVFG', 'FFASASvjksjdsjf', '0000-00-00 00:00:00', 'manu123', ''),
(22, 'CVFG', 'FFASASvjksjdsjf', '0000-00-00 00:00:00', 'manu123', ''),
(23, 'CVFG', 'FFASASvjksjdsjf', '0000-00-00 00:00:00', 'manu123', ''),
(24, 'CVFG', 'FFASASvjksjdsjf', '0000-00-00 00:00:00', 'manu123', '');

-- --------------------------------------------------------

--
-- Table structure for table `registerdpayee`
--

CREATE TABLE IF NOT EXISTS `registerdpayee` (
  `userid` varchar(50) NOT NULL,
  `payeename` varchar(25) NOT NULL,
  `accountnumber` varchar(25) NOT NULL,
  `accounttype` varchar(25) NOT NULL,
  `bankname` varchar(25) NOT NULL,
  `ifsccode` varchar(25) NOT NULL,
  PRIMARY KEY (`accountnumber`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `registerdpayee`
--

INSERT INTO `registerdpayee` (`userid`, `payeename`, `accountnumber`, `accounttype`, `bankname`, `ifsccode`) VALUES
('0', 'arpitha', '26548', 'saving', 'canarabank', 'KARB0000404'),
('manu123', '', '4666', '', '', 'sbi1234567');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_images`
--

CREATE TABLE IF NOT EXISTS `tbl_images` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(50) NOT NULL,
  `image` longblob NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `transaction`
--

CREATE TABLE IF NOT EXISTS `transaction` (
  `transactionid` int(10) NOT NULL AUTO_INCREMENT,
  `transactiondate` date NOT NULL,
  `paymentdate` datetime NOT NULL,
  `payeeid` int(25) NOT NULL,
  `receiveid` int(10) NOT NULL,
  `debitac` varchar(25) NOT NULL,
  `amount` float(10,2) NOT NULL,
  `paymentstat` varchar(25) NOT NULL,
  PRIMARY KEY (`transactionid`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=2147483647 ;

--
-- Dumping data for table `transaction`
--

INSERT INTO `transaction` (`transactionid`, `transactiondate`, `paymentdate`, `payeeid`, `receiveid`, `debitac`, `amount`, `paymentstat`) VALUES
(2147483647, '2012-12-13', '2012-12-03 04:21:10', 111232154, 0, '15000', 100000.00, 'active');

-- --------------------------------------------------------

--
-- Table structure for table `trial`
--

CREATE TABLE IF NOT EXISTS `trial` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `image` varchar(50) NOT NULL,
  `created` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=6 ;

--
-- Dumping data for table `trial`
--

INSERT INTO `trial` (`id`, `image`, `created`) VALUES
(2, '1552051463_tmp_Sign__1_.jpg', '2019-03-25 10:39:59'),
(3, 'IMG_20190219_151055.png', '2019-03-25 10:41:16'),
(4, 'IMG_20190219_151055.png', '2019-03-25 10:45:49'),
(5, 'IMG_20190219_151055.png', '2019-03-26 10:26:14');

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
