<?php 
include 'header.php';


if(isset($_REQUEST['login'])){

    $db= mysqli_connect("localhost","root","","2bank");
    $userid=$_REQUEST['userid'];
    
    $sql="SELECT userid,firstname,lastname,city,state,country,image,date FROM customer 
	WHERE userid='$userid',firstname='$first_name',lastname='$last_name',city='$city',state='$state',country='$country',image='$image_path',date='$datatime'";
	
    $result=mysql_query($sql) or die(mysql_error());
    $rws=  mysql_fetch_array($result);
    
    $user=$rws[0];
    $pwd=$rws[7];    
    
    if($user==$username && $pwd==$image_path){
        session_start();
        $_SESSION['customer_login']=1;
        $_SESSION['cust_id']=$userid;
    header('location:transaction.php'); 
    }
   
else{
    header('location:index.php');  
}}
?>
<?php 
       
if(isset($_SESSION['customer_login'])) 
    header('location:customer_account_summary.php');   
?>

<!DOCTYPE html>

<html>
    <head>
        <title>Digital Banking System</title>
        <link rel="stylesheet" href="newcss.css">
    </head>
    <body>
               
               
        <div class="header">
		    <img src="welcome.jpg" height="400%" width="100%"/>
        </div>
    <link rel="stylesheet" href="style.css" type="text/css">
        
</body>
</html>  




	
	
	
	
	
	