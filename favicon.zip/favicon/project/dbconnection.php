<?php
    $connection = mysqli_connect("localhost","root","","2bank");
?>